using QRCoder;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.AspNetCore.SignalR.Client;

namespace QRdesktopapp
{
    public partial class Form1 : Form
    {
        private HubConnection _hubConnection;
        private string _userId;
        private string Url;
        private string _connectionId;


        public Form1()
        {
            InitializeComponent();
            pictureBoxQRCode.Visible = false;
            button1.Hide();
            textBox1.Hide();


        }

        private async void InitializeSignalRConnection()
        {
            // Initialize SignalR connection


            _hubConnection = new HubConnectionBuilder()
                .WithUrl($"https://localhost:7145/fileUploadHub")
                .Build();

            try
            {
                // Start the connection
                await _hubConnection.StartAsync();
                _connectionId = _hubConnection.ConnectionId; // Retrieve connection ID after connection is established
                Url = $"https://localhost:7145/Upload/Index?connectionId={_connectionId}";
                MessageBox.Show($"Connected to SignalR hub with Connection ID: {_connectionId}", "Connection Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                QRCodeGenerator qrGenerator = new QRCodeGenerator();
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(Url, QRCodeGenerator.ECCLevel.Q);
                QRCode qrCode = new QRCode(qrCodeData);
                pictureBoxQRCode.Image = qrCode.GetGraphic(5);


                // Subscribe to the file upload event
                _hubConnection.On<string>("FileUploaded", (fileName) =>
                {
                    MessageBox.Show($"File uploaded successfully: {fileName}", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);

                   
                });
                _hubConnection.On<string>("ReceiveMessage", (message) =>
                {
                    MessageBox.Show($"message from server: {message}", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
 
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error connecting to SignalR hub: {ex.Message}", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void buttonGenerate_Click(object sender, EventArgs e)
        {
            buttonGenerate.Visible = false;
            pictureBoxQRCode.Visible = true;
            InitializeSignalRConnection();
            
            // Generate QR code with the provided URL
           await _hubConnection.SendAsync("FileUploaded", "file.FileName");
          
            button1.Show();
            textBox1.Show();
        }


        private void RedirectButton_Click(object sender, EventArgs e)
        {
            // Redirect to the website
            string baseUrl = "https://localhost:7145/Upload/Index";
            string urlWithUserId = $"{baseUrl}?userId={_userId}";

            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = urlWithUserId,
                UseShellExecute = true
            };
            Process.Start(psi);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (_hubConnection != null && _hubConnection.State == HubConnectionState.Connected)
            {
                var message = textBox1.Text;
                if (!string.IsNullOrWhiteSpace(message))
                {
                    await _hubConnection.InvokeAsync("BroadcastMessage", _connectionId, message);
                }
                else
                {
                    MessageBox.Show("Please enter a message.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
          
           
        }
    }
}
